{application,castore,
             [{config_mtime,1778338329},
              {optional_applications,[]},
              {applications,[kernel,stdlib,elixir,logger]},
              {description,"Up-to-date CA certificate store."},
              {modules,['Elixir.CAStore']},
              {registered,[]},
              {vsn,"1.0.18"}]}.
